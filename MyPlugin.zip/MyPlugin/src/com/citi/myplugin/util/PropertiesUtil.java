package com.citi.myplugin.util;

import com.intellij.openapi.application.PathManager;
import org.eclipse.jgit.util.StringUtils;

import java.io.File;
import java.io.FileInputStream;
import java.io.FileOutputStream;
import java.io.IOException;
import java.util.Properties;


public class PropertiesUtil {

    private static final String PROPERTIES_FILE = "/.idea/myplugin_settings.properties";

    private static final String COMMON_PROPERTIES_FILE = "common_plugin_settings.properties";

    private static final String SOME_PROPERTY = "SOME_PROPERTY";


    public static void updateSomeProperty(String projectPath, String value) {
        updateProperty(projectPath + PROPERTIES_FILE, SOME_PROPERTY, value);
    }

    public static String readSomeProperty(String projectPath) {
        return readProperty(projectPath + PROPERTIES_FILE, SOME_PROPERTY);
    }

    public static void updateSomePropertyInCommonPlace(String value) {
        updateProperty(PathManager.getPluginsPath() + COMMON_PROPERTIES_FILE, SOME_PROPERTY, value);
    }

    public static String readSomePropertyFromCommonPlace() {
        return readProperty(PathManager.getPluginsPath() + COMMON_PROPERTIES_FILE, SOME_PROPERTY);
    }

    private static Long readLongProperty(String filePath, String propertyKey) {
        String property = readProperty(filePath, propertyKey);
        if (StringUtils.isEmptyOrNull(property)) {
            return null;
        }
        try {
            return Long.parseLong(property);
        } catch (Exception e) {
            return null;
        }
    }

    private static Boolean readBooleanProperty(String filePath, String propertyKey) {
        String property = readProperty(filePath, propertyKey);
        if (StringUtils.isEmptyOrNull(property)) {
            return null;
        }
        try {
            return Boolean.parseBoolean(property);
        } catch (Exception e) {
            return null;
        }
    }

    private static String readProperty(String filePath, String property) {
        try {
            FileInputStream in = new FileInputStream(filePath);
            Properties props = new Properties();
            props.load(in);
            in.close();
            return props.getProperty(property);
        } catch (Exception e) {
            return null;
        }
    }

    private static void updateProperty(String filePath, String property, String value) {
        try {
            createPropertiesFileWhenNeeded(filePath);
            Properties properties = readProperties(filePath);

            FileOutputStream out = new FileOutputStream(filePath);
            properties.setProperty(property, value);
            properties.store(out, null);
            out.close();
        } catch (Exception e) {
        }
    }

    private static void createPropertiesFileWhenNeeded(String filePath) throws IOException {
        File newFile = new File(filePath);
        if (!newFile.exists()) {
            newFile.createNewFile();
        }
    }

    private static Properties readProperties(String filePath) {
        try {
            FileInputStream in = new FileInputStream(filePath);
            Properties props = new Properties();
            props.load(in);
            in.close();
            return props;
        } catch (Exception e) {
            return null;
        }
    }
}
