package com.citi.myplugin.util;

import com.intellij.notification.*;
import com.intellij.openapi.project.Project;

public class NotificationsUtil {

    public static final NotificationGroup GROUP_DISPLAY_ID_INFO = new NotificationGroup("Git commit plugin", NotificationDisplayType.BALLOON, true);

    public static void displayNotification(Project project, String message, NotificationType type) {
        Notification notification = GROUP_DISPLAY_ID_INFO.createNotification(message, type);
        Notifications.Bus.notify(notification, project);
    }
}
