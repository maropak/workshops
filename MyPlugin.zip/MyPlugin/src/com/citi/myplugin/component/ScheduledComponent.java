package com.citi.myplugin.component;


import com.citi.myplugin.util.NotificationsUtil;
import com.intellij.notification.NotificationType;
import com.intellij.openapi.components.ApplicationComponent;
import com.intellij.openapi.project.Project;
import com.intellij.openapi.project.ProjectManager;
import com.intellij.openapi.ui.Messages;
import org.jetbrains.annotations.NotNull;

import java.util.concurrent.Executors;
import java.util.concurrent.ScheduledExecutorService;
import java.util.concurrent.TimeUnit;

public class ScheduledComponent implements ApplicationComponent {

    public static final long SCHEDULE_FIXED_RATE_MILLS = 60*1000;

    @NotNull
    public String getComponentName() {
        return "Scheduled Component";
    }

    @Override
    public void initComponent() {
        ScheduledExecutorService executor = Executors.newScheduledThreadPool(1);
        executor.scheduleAtFixedRate(() -> getTextForNotification(), 5, SCHEDULE_FIXED_RATE_MILLS, TimeUnit.MILLISECONDS);
    }

    private void getTextForNotification() {
        Project[] openProjects = ProjectManager.getInstance().getOpenProjects();
        for (Project openProject : openProjects) {
            try {
                if (openProject.getName().equals("MyPlugin")) {
                    String message = Messages.showPasswordDialog(openProject, "Message", "Input message", Messages.getQuestionIcon());
                    int result = Messages.showYesNoDialog(openProject, "Do you want display message ?", "Display Message", Messages.getQuestionIcon());
                    if (result == Messages.YES) {
                        NotificationsUtil.displayNotification(openProject, message, NotificationType.INFORMATION);
                    }
                }
            } catch (Exception e) {
                e.printStackTrace(); // TODO
            }
        }
    }

    @Override
    public void disposeComponent() {
    }
}
