package com.citi.myplugin.component;

import com.citi.myplugin.util.NotificationsUtil;
import com.intellij.notification.NotificationType;
import com.intellij.openapi.application.ApplicationManager;
import com.intellij.openapi.components.ApplicationComponent;
import com.intellij.openapi.project.Project;
import com.intellij.openapi.project.ProjectManager;
import com.intellij.openapi.vfs.VirtualFileManager;
import com.intellij.openapi.vfs.newvfs.BulkFileListener;
import com.intellij.openapi.vfs.newvfs.events.VFileContentChangeEvent;
import com.intellij.openapi.vfs.newvfs.events.VFileEvent;
import com.intellij.util.messages.MessageBus;
import com.intellij.util.messages.MessageBusConnection;
import org.jetbrains.annotations.NotNull;

import java.util.List;


public class OnFileSaveComponent implements ApplicationComponent {
    @NotNull
    public String getComponentName() {
        return "My On-Save Component";
    }

    public void initComponent() {
        MessageBus bus = ApplicationManager.getApplication().getMessageBus();

        MessageBusConnection connection = bus.connect();

        connection.subscribe(VirtualFileManager.VFS_CHANGES, new BulkFileListener.Adapter() {
            @Override
            public void after(@NotNull List<? extends VFileEvent> events) {
                for (VFileEvent e : events) {
                    if (e instanceof VFileContentChangeEvent) {
                        String documentPath = e.getFile().getPath();
                        if (documentPath.endsWith(".txt")) {
                            Project project = getCurrentProject(documentPath);
                            if (project == null) {
                                return;
                            }
                            NotificationsUtil.displayNotification(project, e.getFile().getName(), NotificationType.INFORMATION);
                        }
                        break;
                    }

                }
            }
        });
    }

    private Project getCurrentProject(String documentPath) {
        Project [] openProjects = ProjectManager.getInstance().getOpenProjects();
        for (Project openProject : openProjects) {
            if (documentPath.startsWith(openProject.getBasePath())) {
                return openProject;
            }
        }
        return null;
    }

    public void disposeComponent() {
    }
}
