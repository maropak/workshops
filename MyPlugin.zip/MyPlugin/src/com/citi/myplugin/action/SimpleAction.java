package com.citi.myplugin.action;

import com.citi.myplugin.util.NotificationsUtil;
import com.intellij.notification.NotificationType;
import com.intellij.openapi.actionSystem.AnAction;
import com.intellij.openapi.actionSystem.AnActionEvent;
import com.intellij.openapi.actionSystem.PlatformDataKeys;
import com.intellij.openapi.project.Project;

public class SimpleAction extends AnAction {

    @Override
    public void actionPerformed(AnActionEvent event) {
        Project project = event.getData(PlatformDataKeys.PROJECT);
        NotificationsUtil.displayNotification(project, project.getBasePath(), NotificationType.INFORMATION);
    }
}
