package com.citi.myplugin.extension;

import com.citi.myplugin.util.PropertiesUtil;
import com.intellij.openapi.project.Project;
import com.intellij.openapi.wm.ToolWindow;
import com.intellij.openapi.wm.ToolWindowFactory;

import javax.swing.*;
import java.awt.*;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;

/**
 * Created by ml03602 on 2017-11-21.
 */
public class MyToolWindowFactory implements ToolWindowFactory {

    @Override
    public void createToolWindowContent(Project project, ToolWindow toolWindow) {
        JPanel panel = new JPanel(new GridLayout(2,1));
        JPanel panel1 = new JPanel();
        panel.add(panel1);
        addText(panel1, project);
        toolWindow.getComponent().add(panel);
    }

    private void addText(JPanel panel, Project project) {
        String basepath = project.getBasePath();
        panel.add(new JLabel("Insert Text)"));
        JTextField text = new JTextField("", 20);
        text.setText(PropertiesUtil.readSomeProperty(basepath));
        panel.add(text);

        JButton updateButton = new JButton("Set");
        panel.add(updateButton);
        updateButton.addActionListener(new ActionListener() {
            public void actionPerformed(ActionEvent e) {

                PropertiesUtil.updateSomeProperty(basepath, "" + text.getText());
            }
        });
    }

    public class ObjectivesGUI{
        private JPanel panel1;

        public ObjectivesGUI(JPanel pane){
            JFrame frame = new JFrame("ObjectivesGUI");
            panel1 = pane;
            frame.setContentPane(panel1);
            frame.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
            frame.pack();
            frame.setVisible(true);
        }

        public JPanel getPanel1(){
            return panel1;
        }
    }
}
