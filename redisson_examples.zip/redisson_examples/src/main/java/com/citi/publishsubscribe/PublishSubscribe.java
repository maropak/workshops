package com.citi.publishsubscribe;

import com.citi.util.RedissonClientProvider;
import org.redisson.api.RTopic;
import org.redisson.api.RedissonClient;
import org.redisson.api.listener.MessageListener;

public class PublishSubscribe {

    public static void main(String[] args) throws InterruptedException {
        new Thread(new Subscriber()).start();
        new Thread(new Subscriber()).start();
        new Thread(new Publisher()).start();
    }

    static class Subscriber implements Runnable {

        private RTopic<Model> topic;

        Subscriber() {
            RedissonClient client = RedissonClientProvider.getClient();
            topic = client.getTopic("anyTopic");
        }

        @Override
        public void run() {

            topic.addListener(new MessageListener<Model>() {
                @Override
                public void onMessage(String channel, Model message) {
                   System.out.println(Thread.currentThread().getName() + "   " + message.getValue());
                }
            });
        }
    }

    static class Publisher implements Runnable {

        private RTopic<Model> topic;

        Publisher() {
            RedissonClient client = RedissonClientProvider.getClient();
            topic = client.getTopic("anyTopic");
        }

        @Override
        public void run() {
            for (int i = 0; i < 10; i++) {
                long clientsReceivedMessage = topic.publish(new Model("aaa", "bbb" + i));
                try {
                    Thread.sleep(1000);
                } catch (InterruptedException e) {
                    e.printStackTrace();
                }
            }
        }
    }
}
