package com.citi.util;

import org.redisson.Redisson;
import org.redisson.api.RedissonClient;
import org.redisson.config.Config;

public class RedissonClientProvider {

    public static RedissonClient getClient() {
        Config config = new Config();
        config.useSingleServer()
                .setAddress("tpc://169.172.130.135:6379").setPassword("hophop123");
//                .setAddress("tpc://127.0.0.1:6379");
        RedissonClient client = Redisson.create(config);
        return client;
    }
}
