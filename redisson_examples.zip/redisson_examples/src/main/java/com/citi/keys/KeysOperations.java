package com.citi.keys;

import com.citi.util.RedissonClientProvider;
import org.redisson.Redisson;
import org.redisson.api.*;
import org.redisson.config.Config;

import java.util.HashMap;
import java.util.List;
import java.util.Map;

public class KeysOperations {

    public static void main(String[] args) {
        RedissonClient client = RedissonClientProvider.getClient();

        RKeys keys = client.getKeys();
        System.out.println("Count : " + keys.count());
        Iterable<String> allKeys = keys.getKeys();
        allKeys.forEach(elem -> System.out.println(elem));

        System.out.println("\n");

        Iterable<String> keysByPattern = keys.getKeysByPattern("any*");
        keysByPattern.forEach(elem -> System.out.println(elem));

//        long numOfDeletedKeys = keys.delete("obj1", "obj2", "obj3");//
//        long deletedKeysAmount = keys.deleteByPattern("test?");//
//        String randomKey = keys.randomKey();
    }

}
