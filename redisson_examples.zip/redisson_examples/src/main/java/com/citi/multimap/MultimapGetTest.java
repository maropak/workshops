package com.citi.multimap;

import com.citi.util.RedissonClientProvider;
import org.redisson.Redisson;
import org.redisson.api.RSetMultimap;
import org.redisson.api.RedissonClient;
import org.redisson.config.Config;

import java.util.Set;

public class MultimapGetTest {

    public static void main(String[] args) {
        RedissonClient client = RedissonClientProvider.getClient();

        RSetMultimap<String, String> setMultimap = client.getSetMultimap("myFish");
// total entries amount
        System.out.println(setMultimap.size()); // 5
// total values amount by key
        System.out.println(setMultimap.get("favoriteFish").size()); // 3
// check entry existence
        System.out.println(setMultimap.containsEntry("favoriteFish", "Ladyfish"));
// and so on ...
    }
}
