package com.citi.remote;

import com.citi.util.RedissonClientProvider;
import org.redisson.Redisson;
import org.redisson.api.RRemoteService;
import org.redisson.api.RedissonClient;
import org.redisson.config.Config;

public class Client {

    public static void main(String[] args) {
        RedissonClient client = RedissonClientProvider.getClient();

        RRemoteService remoteService = client.getRemoteService();
        Service service = remoteService.get(Service.class);
        System.out.println(service.execute());
    }
}
