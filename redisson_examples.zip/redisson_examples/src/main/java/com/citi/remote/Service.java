package com.citi.remote;

public interface Service {

    String execute();
}
