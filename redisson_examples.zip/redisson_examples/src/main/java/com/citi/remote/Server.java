package com.citi.remote;

import com.citi.util.RedissonClientProvider;
import org.redisson.Redisson;
import org.redisson.api.RRemoteService;
import org.redisson.api.RedissonClient;
import org.redisson.config.Config;

public class Server {

    public static void main(String[] args) {
        RedissonClient client = RedissonClientProvider.getClient();

        ServiceImpl yourService = new ServiceImpl();
        RRemoteService remoteService = client.getRemoteService();
        remoteService.register(Service.class, yourService);
    }
}
