package com.citi.configurations;

import com.citi.util.RedissonClientProvider;
import org.redisson.Redisson;
import org.redisson.api.RBucket;
import org.redisson.api.RedissonClient;
import org.redisson.config.Config;

public class JavaConfig {

    public static void main(String[] args) {
        Config config = new Config();
        RedissonClient client = RedissonClientProvider.getClient();

        RBucket<String> bucket = client.getBucket("YourKey2");
        bucket.setAsync("abc"); //  or bucket.set("abc");
        System.out.println(bucket.get());
    }

}
