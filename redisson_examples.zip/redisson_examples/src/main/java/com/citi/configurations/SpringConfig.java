package com.citi.configurations;

import org.redisson.api.RBucket;
import org.redisson.api.RedissonClient;
import org.springframework.context.ApplicationContext;
import org.springframework.context.support.ClassPathXmlApplicationContext;

public class SpringConfig {

    public static void main(String[] args) {
        ApplicationContext ctx = new ClassPathXmlApplicationContext("spring.xml");
        RedissonClient client = (RedissonClient) ctx.getBean("myRedisson1");
        RBucket<String> bucket = client.getBucket("YourKey");

        bucket.setAsync("abc"); //  or bucket.set("abc");
        System.out.println(bucket.get());
    }

}
