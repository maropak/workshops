package com.citi.objectholder;

import com.citi.util.RedissonClientProvider;
import org.redisson.Redisson;
import org.redisson.api.RBucket;
import org.redisson.api.RBuckets;
import org.redisson.api.RedissonClient;
import org.redisson.config.Config;

import java.util.List;
import java.util.Map;

public class BucketTest {

    public static void main(String[] args) {
        RedissonClient client = RedissonClientProvider.getClient();
        RBucket<Model> bucket = client.getBucket("model");
        bucket.set(new Model("test"));
        Model model = bucket.get();
        System.out.println(model.getName());

        RBuckets buckets = client.getBuckets();
        System.out.println("Bucekts size" + bucket.size());

        List<RBucket<Model>> foundBuckets = buckets.find("mode*");
        System.out.println("Bucekts size" + foundBuckets.size());
        Model model2 = foundBuckets.get(0).get();
        System.out.println(model2.getName());

        Map<String, Model> loadedBucketModel= buckets.get("model");
        System.out.println(loadedBucketModel);
    }
}
