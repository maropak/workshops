package com.citi.atomic;

import com.citi.util.RedissonClientProvider;
import org.redisson.Redisson;
import org.redisson.api.RAtomicLong;
import org.redisson.api.RFuture;
import org.redisson.api.RedissonClient;
import org.redisson.config.Config;

public class AtomicSyncAsync {

    public static void main(String[] args) {
        RedissonClient client = RedissonClientProvider.getClient();

        RAtomicLong longObject = client.getAtomicLong("myLong");
// sync way
        longObject.set(10);
        System.out.println("Value : " + longObject.getAndDecrement());
        System.out.println("Value : " + longObject.get());
// async way
        RFuture<Boolean> future = longObject.compareAndSetAsync(3, 501);
        future.thenAccept(res -> {
            System.out.println("Value : " + res);
        });

        RFuture<Boolean> future2 = longObject.compareAndSetAsync(9, 501);
// handle the result or exception here.
        future2.handle((result, exception) -> {
            System.out.println("Value2 : " + result);
            return result;
        });
    }
}
