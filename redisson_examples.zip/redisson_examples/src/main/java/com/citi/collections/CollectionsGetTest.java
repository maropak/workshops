package com.citi.collections;

import com.citi.publishsubscribe.Model;
import com.citi.util.RedissonClientProvider;
import org.redisson.api.RMap;
import org.redisson.api.RSet;
import org.redisson.api.RedissonClient;

public class CollectionsGetTest {


    public static void main(String[] args) {
        RedissonClient client = RedissonClientProvider.getClient();

        RMap<String, Model> map = client.getMap("anyMap");
        Model newModel = map.get("123");
        System.out.println(newModel.getValue());

        RSet<Model> set = client.getSet("anySet");
        System.out.println(set.size());
    }

}
