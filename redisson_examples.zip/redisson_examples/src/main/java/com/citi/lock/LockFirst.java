package com.citi.lock;

import com.citi.executor.RunnableTask;
import com.citi.util.RedissonClientProvider;
import org.redisson.Redisson;
import org.redisson.api.RLock;
import org.redisson.api.RScheduledExecutorService;
import org.redisson.api.RedissonClient;
import org.redisson.config.Config;

import java.util.concurrent.TimeUnit;

// distributed reentrant Lock
public class LockFirst {

    public static void main(String[] args) throws InterruptedException {
        RedissonClient client = RedissonClientProvider.getClient();

        RLock lock = client.getLock("anyLock");
        lock.lock();
        Thread.sleep(30000);
        lock.unlock();
    }
}
