package com.example.integration.messaging;

import com.example.integration.model.Confirmation;
import com.example.integration.model.News;
import com.example.integration.repository.ConfirmationRepository;
import com.example.integration.service.NewsProcessor;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.core.io.ClassPathResource;
import org.springframework.integration.core.MessagingTemplate;
import org.springframework.test.context.ContextConfiguration;
import org.springframework.test.context.junit4.SpringJUnit4ClassRunner;

import java.io.File;

import static org.hamcrest.CoreMatchers.is;
import static org.junit.Assert.*;
import static org.mockito.Matchers.any;
import static org.mockito.Mockito.when;

@ContextConfiguration({"spring-integration-idempotent-receiver-config.xml",
		"spring-integration-infrastructure-config.xml",
		"spring-integration-marshalling-config.xml",
		"spring-integration-xml-splitting-config.xml",
		"mocks.xml"})
@RunWith(SpringJUnit4ClassRunner.class)
public class MessagingIntegrationTests {

	@Autowired
	private ConfirmationRepository confirmationRepository;
	@Autowired
	private NewsProcessor newsProcessor;

	@Autowired MessagingTemplate template;

	@Test
	public void sendSingleXmlNewsTwice() throws Exception {
		when(newsProcessor.process(any(News.class))).thenReturn(new Confirmation("num1"));
		File xmlFile = new ClassPathResource("news-sample.xml", getClass()).getFile();
		template.convertAndSend("xmlNewses", xmlFile);

		String payload = template.receiveAndConvert("xmlConfirmations", String.class);
		assertTrue(( payload).contains("<confirmation"));
		
		template.convertAndSend("xmlNewses", xmlFile);
		assertEquals(payload, template.receiveAndConvert("xmlConfirmations", String.class));
	}
	
	@Test 
	public void sendMultipleNewses() throws Exception {
		when(newsProcessor.process(any(News.class))).thenReturn(new Confirmation("num1"));
		when(confirmationRepository.findConfirmationFor(any(News.class))).thenReturn(new Confirmation("num2"));

		File xmlFile = new ClassPathResource("newses-sample.xml", getClass()).getFile();
		template.convertAndSend("mixedXmlNewses", xmlFile);
		
		assertNotNull(template.receiveAndConvert("xmlConfirmations", String.class));
		assertNotNull(template.receiveAndConvert("xmlConfirmations", String.class));
	}
}
