package com.example.integration.messaging;

import com.example.integration.model.Confirmation;
import com.example.integration.service.ConfirmationMarshaller;
import org.junit.Test;
import org.springframework.xml.xpath.Jaxp13XPathTemplate;
import org.springframework.xml.xpath.XPathOperations;

import javax.xml.transform.dom.DOMResult;
import javax.xml.transform.dom.DOMSource;

import static org.hamcrest.CoreMatchers.is;
import static org.junit.Assert.assertThat;
import static org.mockito.Mockito.mock;
import static org.mockito.Mockito.when;

public class ConfirmationMarshallerTest {

	ConfirmationMarshaller marshaller = new ConfirmationMarshaller();

	XPathOperations xpathTemplate = new Jaxp13XPathTemplate();

	@Test
	public void marshallDOM() throws Exception {
		Confirmation confirmation = mock(Confirmation.class);
		when(confirmation.getConfirmationNumber()).thenReturn("123");
		DOMResult result = new DOMResult();
		marshaller.marshal(confirmation, result);
		DOMSource source = new DOMSource(result.getNode());
		assertThat(xpathTemplate.evaluateAsString(
				"/confirmation/@confirmationNumber", source),
				is("123"));
	}

}
