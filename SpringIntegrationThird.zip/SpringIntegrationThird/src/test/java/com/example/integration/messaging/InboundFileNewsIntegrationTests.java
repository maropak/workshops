package com.example.integration.messaging;

import com.example.integration.model.Confirmation;
import com.example.integration.model.News;
import com.example.integration.repository.ConfirmationRepository;
import com.example.integration.service.NewsProcessor;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.messaging.Message;
import org.springframework.messaging.PollableChannel;
import org.springframework.test.context.ContextConfiguration;
import org.springframework.test.context.junit4.SpringJUnit4ClassRunner;
import org.springframework.xml.transform.StringSource;
import org.springframework.xml.xpath.Jaxp13XPathTemplate;
import org.springframework.xml.xpath.XPathOperations;

import static org.hamcrest.CoreMatchers.is;
import static org.junit.Assert.*;
import static org.mockito.Matchers.any;
import static org.mockito.Mockito.when;


@ContextConfiguration
@RunWith(SpringJUnit4ClassRunner.class)
public class InboundFileNewsIntegrationTests {

	@Autowired
	private ConfirmationRepository confirmationRepository;
	@Autowired
	private NewsProcessor newsProcessor;

	@Autowired
	private PollableChannel xmlConfirmations;

	XPathOperations xpathTemplate = new Jaxp13XPathTemplate();

	@Test
	public void filesReceived() throws Exception {
		when(newsProcessor.process(any(News.class))).thenReturn(new Confirmation("num1"));
		when(confirmationRepository.findConfirmationFor(any(News.class))).thenReturn(new Confirmation("num2"));
		when(newsProcessor.process(any(News.class))).thenReturn(new Confirmation("num3"));

		String xpath = "/confirmation/@confirmationNumber";
		int messageCount = 0;
		for(;;) {
			Message<?> receivedMessage = xmlConfirmations.receive(2500);
			if (receivedMessage == null) {
				break;
			}
			messageCount++;
			String payload = (String) receivedMessage.getPayload();
			String newsTest = xpathTemplate.evaluateAsString(xpath, new StringSource(payload));
			assertTrue(newsTest.startsWith("num"));
		}
		assertEquals(3, messageCount);
	}

}
