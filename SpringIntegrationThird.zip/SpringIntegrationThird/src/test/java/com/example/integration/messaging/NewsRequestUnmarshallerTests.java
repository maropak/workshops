package com.example.integration.messaging;

import com.example.integration.model.News;
import com.example.integration.service.NewsRequestUnmarshaller;
import org.junit.Before;
import org.junit.Test;
import org.springframework.core.io.ClassPathResource;

import javax.xml.transform.Source;
import javax.xml.transform.stream.StreamSource;

import static org.hamcrest.CoreMatchers.is;
import static org.junit.Assert.assertThat;

public class NewsRequestUnmarshallerTests {

	private Source newsSource;
	private NewsRequestUnmarshaller unmarshaller = new NewsRequestUnmarshaller();

	@Before
	public void setup() throws Exception {
		newsSource = new StreamSource(
						new ClassPathResource("news-sample.xml", getClass()).getFile());
	}

	@Test
	public void unmarshall() throws Exception {
		News news = (News) unmarshaller.unmarshal(newsSource);
		assertThat(news.getText(), is("someText1"));
		assertThat(news.getAuthor(), is("Author1"));
	}

}
