package com.example.integration.messaging;

import com.example.integration.model.Confirmation;
import com.example.integration.model.News;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.core.io.ClassPathResource;
import org.springframework.integration.core.MessagingTemplate;
import org.springframework.test.context.ContextConfiguration;
import org.springframework.test.context.junit4.SpringJUnit4ClassRunner;

import java.io.File;

import static org.hamcrest.CoreMatchers.is;
import static org.junit.Assert.assertThat;
import static org.junit.Assert.assertTrue;
import static org.mockito.Mockito.mock;
import static org.mockito.Mockito.when;

@ContextConfiguration
@RunWith(SpringJUnit4ClassRunner.class)
public class MarshallingIntegrationTests {

	@Autowired MessagingTemplate template;
	
	@Test
	public void inboundNewsXml() throws Exception {
		File xmlFile = new ClassPathResource("news-sample.xml", getClass()).getFile();
		
		template.convertAndSend("xmlNewses", xmlFile);
		
		News receivedPayload = template.receiveAndConvert("news", News.class);
		assertThat(receivedPayload.getText(), is("someText1"));
	}

	@Test
	public void outboundConfirmation() throws Exception {
		Confirmation confirmation = mock(Confirmation.class);
		when(confirmation.getConfirmationNumber()).thenReturn("UUID");
		
		template.convertAndSend("confirmations", confirmation);
		
		String receivedPayload = template.receiveAndConvert("xmlConfirmations", String.class);
		assertTrue(receivedPayload.contains("confirmationNumber=\"UUID\""));
	}

}
