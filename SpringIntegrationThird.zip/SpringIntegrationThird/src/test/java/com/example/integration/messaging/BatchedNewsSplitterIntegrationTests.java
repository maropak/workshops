package com.example.integration.messaging;

import org.junit.Test;
import org.junit.runner.RunWith;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.core.io.ClassPathResource;
import org.springframework.integration.core.MessagingTemplate;
import org.springframework.test.context.ContextConfiguration;
import org.springframework.test.context.junit4.SpringJUnit4ClassRunner;
import org.springframework.xml.transform.StringSource;
import org.springframework.xml.xpath.Jaxp13XPathTemplate;
import org.springframework.xml.xpath.XPathOperations;

import java.io.File;

import static org.hamcrest.CoreMatchers.is;
import static org.junit.Assert.assertThat;

@ContextConfiguration
@RunWith(SpringJUnit4ClassRunner.class)
public class BatchedNewsSplitterIntegrationTests {

	XPathOperations xpathTemplate = new Jaxp13XPathTemplate();
	
	@Autowired MessagingTemplate template;

	@Test
	public void inboundSingleNewsXml() throws Exception {
		File newsFile = new ClassPathResource("news-sample.xml", getClass()).getFile();
		template.convertAndSend("mixedXmlNewses", newsFile);

		Object receivedPayload = template.receive("xmlNewses").getPayload();
//		assertThat(receivedPayload, is(String.class));
		assertThat(xpathTemplate.evaluateAsString("/news/@author",
				new StringSource((String) receivedPayload)), is("Author1"));
	}

	@Test(timeout = 2000)
	public void inboundMultipleNewsXml() throws Exception {
		File newsFile = new ClassPathResource("newses-sample.xml", getClass()).getFile();
		template.convertAndSend("mixedXmlNewses", newsFile);

		String receivedPayload = template.receiveAndConvert("xmlNewses", String.class);

		assertThat(xpathTemplate.evaluateAsString("/news/@author",
				new StringSource( receivedPayload)), is("Author1"));
		assertThat(xpathTemplate.evaluateAsString("/news/@author",
				new StringSource( template.receiveAndConvert("xmlNewses", String.class))),
				is("Author2"));
	}
}
