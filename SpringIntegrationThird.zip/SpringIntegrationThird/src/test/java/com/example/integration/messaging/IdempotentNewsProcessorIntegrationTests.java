package com.example.integration.messaging;

import com.example.integration.model.Confirmation;
import com.example.integration.model.News;
import com.example.integration.repository.ConfirmationRepository;
import com.example.integration.service.NewsProcessor;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.integration.core.MessagingTemplate;
import org.springframework.test.context.ContextConfiguration;
import org.springframework.test.context.junit4.SpringJUnit4ClassRunner;

import static org.hamcrest.CoreMatchers.is;
import static org.junit.Assert.assertThat;
import static org.mockito.Mockito.*;


@ContextConfiguration
@RunWith(SpringJUnit4ClassRunner.class)
public class IdempotentNewsProcessorIntegrationTests {

	News news = mock(News.class);

	@Autowired
	ConfirmationRepository confirmationRepository;
	@Autowired
	NewsProcessor newsProcessor;
	@Autowired MessagingTemplate template;

	// 1. processor called, message returned
	// 2. processor called, null returned (verify 2 times)
	// 3. ex thrown, because result required
	// 4. confirmationRepository called

	@Test
	public void idempotence() throws Exception {
		Confirmation confirmation = mock(Confirmation.class);
		when(newsProcessor.process(news)).thenReturn(confirmation);
		template.convertAndSend("news", news);
		
		Confirmation firstConfirmation =  template.receiveAndConvert("confirmations", Confirmation.class);
		
		when(confirmationRepository.findConfirmationFor(news)).thenReturn(firstConfirmation);
		template.convertAndSend("news", news);

		Confirmation secondConfirmation = template.receiveAndConvert("confirmations", Confirmation.class);
		assertThat(secondConfirmation, is(firstConfirmation));
		verify(newsProcessor, times(2)).process(news);
	}

}
