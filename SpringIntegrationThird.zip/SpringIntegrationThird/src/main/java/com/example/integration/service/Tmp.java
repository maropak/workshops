package com.example.integration.service;

import java.util.List;

/**
 * Created by maro on 2017-03-25.
 */
public class Tmp {


    public List<OrderItem> split(Order order) {
        return order.getItems();
    }


    public Order combine(List<OrderItem> items) {
        return Order.withItems(items);
    }

}
