package com.example.integration.service;

import com.example.integration.model.News;
import org.springframework.oxm.Unmarshaller;
import org.springframework.oxm.XmlMappingException;
import org.springframework.xml.xpath.Jaxp13XPathTemplate;
import org.springframework.xml.xpath.XPathOperations;

import javax.xml.transform.Source;
import java.io.IOException;

public class NewsRequestUnmarshaller implements Unmarshaller {

	private XPathOperations xpathTemplate = new Jaxp13XPathTemplate();

	public boolean supports(Class<?> clazz) {
		return clazz.isAssignableFrom(News.class);
	}

	public Object unmarshal(Source source) throws XmlMappingException,
			IOException {

		String author = xpathTemplate.evaluateAsString("/news/@author", source);
		String text = xpathTemplate.evaluateAsString("/news/text", source);
		return new News(text, author);
	}
	
}
