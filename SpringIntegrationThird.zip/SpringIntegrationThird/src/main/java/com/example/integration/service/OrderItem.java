package com.example.integration.service;

/**
 * Created by maro on 2017-03-25.
 */
public class OrderItem {
}
