package com.example.integration.service;

import com.example.integration.model.Confirmation;
import org.springframework.oxm.Marshaller;
import org.springframework.oxm.MarshallingFailureException;
import org.springframework.oxm.XmlMappingException;
import org.springframework.util.Assert;
import org.w3c.dom.Document;
import org.w3c.dom.Element;

import javax.xml.parsers.DocumentBuilderFactory;
import javax.xml.transform.Result;
import javax.xml.transform.dom.DOMResult;
import java.io.IOException;

public class ConfirmationMarshaller implements Marshaller {

	public boolean supports(Class<?> clazz) {
		return clazz.isAssignableFrom(Confirmation.class);
	}

	public void marshal(Object graph, Result result) throws XmlMappingException, IOException {
		Confirmation confirmation = (Confirmation) graph;
		Assert.hasText(confirmation.getConfirmationNumber(),
			"'confirmationNumber' is missing from reward confirmation");
		
		Document doc;
		try {
			doc = DocumentBuilderFactory.newInstance().newDocumentBuilder().newDocument();
		} catch (Throwable e) {
			throw new MarshallingFailureException("Can't create new Document", e);
		}
		Element elConfirmation = (Element) doc.appendChild(doc.createElement("confirmation"));
		elConfirmation.setAttribute("confirmationNumber", confirmation.getConfirmationNumber());
		
		if (result instanceof DOMResult) {
			((DOMResult) result).setNode(doc);
		} else {
			throw new IllegalArgumentException("Got instance of "
				+ result.getClass().getSimpleName()
				+ " which is not supported");
		}

	}
}
