package com.example.integration.model;

/**
 * Created by maro on 2017-02-26.
 */
public class Order {

}
