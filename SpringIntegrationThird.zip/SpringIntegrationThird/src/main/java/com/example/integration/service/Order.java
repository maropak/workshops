package com.example.integration.service;

import java.util.List;

/**
 * Created by maro on 2017-03-25.
 */
public class Order {
    public List<OrderItem> getItems() {
        return items;
    }

    public static Order withItems(List<OrderItem> items) {
    }
}
