package com.example.integration.service;


import com.example.integration.model.Confirmation;

public interface ConfirmationProcessor {

	void process(Confirmation confirmation);

}
